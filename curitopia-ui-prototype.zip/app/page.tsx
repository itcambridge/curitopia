'use client'

import { FormEvent, useMemo, useState } from 'react'
import { ArrowRight, ChevronDown, CircleHelp, Clock3, Focus, Layers3, List, Map, MoreHorizontal, Network, Plus, RotateCcw, Send, Sparkles, Target, Timer, Waypoints, X } from 'lucide-react'

type Question = { id: number; text: string; color: string; orbit: number; angle: number }

const starterQuestions: Question[] = [
  { id: 1, text: 'Why do we dream?', color: '#ffb84d', orbit: 0, angle: 0 },
  { id: 2, text: 'What happens in the brain when we dream?', color: '#53baff', orbit: 1, angle: 205 },
  { id: 3, text: 'Could dreams help us solve problems?', color: '#ed8dc1', orbit: 1, angle: 290 },
  { id: 4, text: 'Are dreams a way of processing emotions?', color: '#f5a653', orbit: 1, angle: 25 },
  { id: 5, text: 'Why do some dreams feel meaningful?', color: '#ef8bc2', orbit: 1, angle: 155 },
  { id: 6, text: 'What is the purpose of REM sleep?', color: '#7ee4be', orbit: 2, angle: 58 },
  { id: 7, text: 'Could dreams show us possible futures?', color: '#559aff', orbit: 2, angle: 345 },
  { id: 8, text: 'Do we all dream in the same way?', color: '#71e8c0', orbit: 2, angle: 88 },
  { id: 9, text: 'Can dreams influence our decisions?', color: '#a866f5', orbit: 2, angle: 225 },
  { id: 10, text: 'Do other animals dream?', color: '#a36cff', orbit: 2, angle: 250 },
  { id: 11, text: 'Can AI dream?', color: '#a55af1', orbit: 3, angle: 330 },
  { id: 12, text: 'What if dreams are a form of time travel?', color: '#70e4b9', orbit: 3, angle: 310 },
]

function QuestionMap({ questions, selected, onSelect }: { questions: Question[]; selected: number; onSelect: (id: number) => void }) {
  const nodes = useMemo(() => questions.map((q, index) => {
    if (q.orbit === 0) return { ...q, x: 50, y: 50, radius: 13 }
    const radius = q.orbit === 1 ? 25 : q.orbit === 2 ? 36 : 43
    const rad = (q.angle * Math.PI) / 180
    return { ...q, x: 50 + Math.cos(rad) * radius, y: 50 + Math.sin(rad) * radius, radius: q.orbit === 1 ? 7.5 : 6.2, delay: `${index * 80}ms` }
  }), [questions])

  return <svg className="question-map" viewBox="0 0 100 100" role="img" aria-label="Orbital map of connected questions">
    <defs>
      <filter id="glow"><feGaussianBlur stdDeviation="1.5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <radialGradient id="core"><stop stopColor="#ffb84d" stopOpacity=".42"/><stop offset="1" stopColor="#ff9d2f" stopOpacity="0"/></radialGradient>
    </defs>
    {[18, 29, 40, 47].map(r => <circle key={r} cx="50" cy="50" r={r} fill="none" stroke="#4b8dcb" strokeOpacity=".22" strokeWidth=".12" strokeDasharray=".8 .8" />)}
    {nodes.filter(n => n.orbit > 0).map(n => <line key={`line-${n.id}`} x1="50" y1="50" x2={n.x} y2={n.y} stroke={n.color} strokeOpacity=".16" strokeWidth=".12" />)}
    <circle cx="50" cy="50" r="17" fill="url(#core)" filter="url(#glow)" />
    {nodes.map(n => <g key={n.id} className={`map-node ${n.id === selected ? 'selected' : ''}`} style={{ animationDelay: n.delay }} onClick={() => onSelect(n.id)} tabIndex={0} role="button" aria-label={n.text}>
      <circle cx={n.x} cy={n.y} r={n.radius} fill={n.color} fillOpacity={n.orbit === 0 ? .18 : .14} stroke={n.color} strokeWidth={n.id === selected ? .45 : .25} filter="url(#glow)" />
      {n.orbit === 0 ? <><text x={n.x} y={n.y - 1.8} textAnchor="middle" className="central-text">Why do</text><text x={n.x} y={n.y + 2.4} textAnchor="middle" className="central-text">we dream?</text></> : <foreignObject x={n.x - n.radius + .4} y={n.y - n.radius + .5} width={n.radius * 2 - .8} height={n.radius * 2 - 1}><div className="node-copy">{n.text}</div></foreignObject>}
    </g>)}
  </svg>
}

export default function Page() {
  const [mode, setMode] = useState<'Focus' | 'Quickfire'>('Focus')
  const [questions, setQuestions] = useState(starterQuestions)
  const [input, setInput] = useState('')
  const [selected, setSelected] = useState(1)
  const [ended, setEnded] = useState(false)

  function addQuestion(event?: FormEvent) {
    event?.preventDefault()
    const text = input.trim()
    if (!text) return
    const next = { id: Date.now(), text, color: ['#55baff', '#a969f4', '#71e7bf', '#ef8bc2'][questions.length % 4], orbit: questions.length > 7 ? 3 : 2, angle: (questions.length * 67) % 360 }
    setQuestions(prev => [...prev, next]); setSelected(next.id); setInput('')
  }

  return <main className="app-shell">
    <aside className="sidebar">
      <header className="brand"><div className="brand-mark"><span>c</span><span>q</span></div><div><div className="brand-name">curitopia</div><div className="tagline">Keep asking. Go further.</div></div></header>
      <section className="mode-switch" aria-label="Choose exploration mode"><button className={mode === 'Focus' ? 'active' : ''} onClick={() => setMode('Focus')}><Focus size={15}/> Focus</button><button className={mode === 'Quickfire' ? 'active' : ''} onClick={() => setMode('Quickfire')}><Timer size={15}/> Quickfire</button></section>
      <section className="panel prompt-panel"><div className="panel-label">{mode === 'Focus' ? 'Explore your question' : 'Keep the questions coming'}</div><form onSubmit={addQuestion}><textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Type your next question..." aria-label="Next question" /><button className="add-button" type="submit">Add Question <ArrowRight size={17}/></button></form></section>
      <section className="panel stats-panel"><div className="panel-heading"><span>Today&apos;s exploration</span><ChevronDown size={17}/></div><div className="stats"><div><strong>{questions.length}</strong><span>questions</span></div><div><strong>{Math.max(1, Math.ceil(questions.length / 4))}</strong><span>orbits</span></div><div><strong>{questions.length + 3}</strong><span>new directions</span></div></div></section>
      <section className="panel journey"><div className="panel-heading"><span><Waypoints size={17}/> Your journey</span><span className="live-dot" /></div><div className="journey-row"><Network size={17}/><span>Longest chain</span><b>8</b></div><div className="journey-row"><Target size={17}/><span>Furthest from start</span><b>4.2×</b></div><div className="journey-row"><Clock3 size={17}/><span>Time exploring</span><b>18 mins</b></div></section>
      <div className="connections"><Sparkles size={29}/><div><strong>You&apos;re making<br/>connections.</strong><p>Your thinking is expanding<br/>in new directions.</p></div></div>
      <button className="end-button" onClick={() => setEnded(true)}>{ended ? <RotateCcw size={17}/> : <Layers3 size={17}/>} {ended ? 'Start new exploration' : 'End session & explore'}</button>
    </aside>
    <section className="map-area"><div className="star-field"/><div className="topbar"><div className="map-tabs"><button className="selected"><Map size={17}/> Map</button><button><List size={17}/> List</button><button><Waypoints size={17}/> Timeline</button></div><button className="more" aria-label="More options"><MoreHorizontal size={20}/></button></div><div className="map-heading"><p>{ended ? 'Your collected questions' : 'A universe of curiosity'}</p><h1>{questions.length} questions orbiting one idea</h1></div><QuestionMap questions={questions} selected={selected} onSelect={setSelected}/><div className="map-footer"><span><span className="status-dot"/> Live exploration</span><span>Click any question to focus</span></div></section>
  </main>
}
